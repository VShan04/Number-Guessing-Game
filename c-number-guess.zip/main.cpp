/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <cstdlib>
#include <ctime>

int main() {
   // Initialize random seed 
    std::srand(std::time(0));

    // Generate random number between 1 and 1000
    int randomNumber = std::rand() % 1000 + 1;
    int userGuess = 0;
    int numberOfAttempts = 0;

    std::cout << "Welcome to guessing game!" << std::endl;
    std::cout << "A number has been selected between 1 and 1000.Try to guess it!" << std::endl;

    // Game loop
    while (userGuess != randomNumber) {
        std::cout << "Enter your guess: ";
        std::cin >> userGuess;
        numberOfAttempts++;

        if (userGuess < randomNumber) {
            std::cout << "Too low! Try again." << std::endl;
        } else if (userGuess > randomNumber) {
            std::cout << "Too high! Try again." << std::endl;
        } else {
            std::cout << "Congratulations! Your guess is correct " << numberOfAttempts << " attempts." << std::endl;
        }
    }

    return 0;
}
